
<?php
$link = mysqli_connect("localhost", "neha23", "mummypapa23", "society_management");
?>